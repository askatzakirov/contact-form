import React from 'react';
import { Field, reduxForm } from 'redux-form';

class ContactMe extends React.Component{
      constructor(){
         super();
      }
      render() {
        const { handleSubmit } = this.props;
        <form autoComplete="off" onSubmit={handleSubmit} ref="contactForm" >
        return (
          <div className="column is-half">
            <div className='tl pa3 w-40 leftZone' id='contactBox'>
              <h1 className='f1'>{'Contact Me'}</h1>
              <main className="black-80">
                <form autoComplete="off" ref="contactForm" >
                  <fieldset className="ba b--transparent ph0 mh0">
                    <div className="box-left">
                    <Field className="pa2 input-reset ba bg-transparent hover-bg-black hover-white w-100" label="Full Name" name="name" id="name" type="text"/>
                    </div>
                    
                    <div className="box-left">
                     <label className="clip" name="email" htmlFor="email-address">Email</label>
                     <Field className="pa2 input-reset ba bg-transparent hover-bg-black hover-white w-100" name="email"  label="Email" id="email" type="email" placeholder="Email Address"/>
                    </div>
                    
                    <div className="cf">
                      <label className="clip" htmlFor="subject">Subject</label>
                      <Field className="fixposition pa2 input-reset ba bg-transparent hover-bg-black hover-white w-100" name="subject" label="subject" type="text" id="subject" placeholder="Subject"/>
                    </div>
                    
                    <div className="cf">
                      <label className="clip" htmlFor="subject">Message</label>
                      <Field className="fixposition input-reset ba hover-bg-black hover-white textarea" name="message" type="text" id="message" component="textarea" placeholder="Message"/>
                    </div>
                  </fieldset>
                  
                  <button type="submit" className="pseudoBtn fixposition" label="send">SEND</button>
                </form>
              </main>
            </div> 
          </div>
     )
   }
}

export default reduxForm({
   form: 'contact'
})(Contact);

export default reduxForm({
  form: 'contactMe',
  validate
})(ContactMe);