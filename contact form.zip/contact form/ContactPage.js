import React from 'react';
import Background from './layout/Background;
import Contact from './Contact';

class ContactPage extends React.Component {
	constructor(props) {
		super(props);
	    this.handleSubmit = this.handleSubmit.bind(this);
	}
	
	handleSubmit = values => {
	    console.log(values);
       };

       render() {
	return(
		<div className="columns">
			<Background/>
			<Contact onSubmit = {this.handleSubmit} />
	  </div>
	)
       }
}
export default ContactPage